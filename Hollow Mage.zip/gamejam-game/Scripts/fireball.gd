extends Area2D

@export var direction: int
@export var SPEED := 15
var particles := load("res://Scenes/particle.tscn")

func _ready() -> void:
	global_position = $"../../Player/Marker2D".global_position 
	#position -= Vector2(100, 100)
	print(position)
	if $"../../Player/PlayerSprite".flip_h:
		$Sprite2D.flip_h = true
		direction = -1  # 1 means rights
	else:
		$Sprite2D.flip_h = false
		direction = 1  # 1 means rights

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	position += Vector2(SPEED, 0) * direction
	# Deleting fireball
	if position.x > 1152 or position.x < 0:
		queue_free()


func _on_body_entered(body: Node2D) -> void:
	if body != $"../../Levels/Level1/Normal":
		body.queue_free()
	Global.colidedBulletPosition = position
	var particle = particles.instantiate()
	$"../../Particles".add_child(particle)
	var parts = particle.get_node("CPUParticles2D")
	parts.emitting = true
	queue_free()
