extends Node

var colidedBulletPosition: Vector2
var JUMPS: int = 5
var playerDead := false
var resetLava := false 
