extends CharacterBody2D


const SPEED = 300.0
@export var faces_left: bool = false
signal enemy_colided_player
var origPosition
var isAttacking: bool

func _ready() -> void:
	origPosition = position
	
func _physics_process(delta: float) -> void:
	$AnimatedSprite2D.flip_h = faces_left
	
	position.x = origPosition.x
	if not is_on_floor():
		velocity.y += 980 * delta
	if not isAttacking:
		$AnimatedSprite2D.play("idle")
	move_and_slide()
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		if collision.get_collider().name != 'Player':
			continue
		$AnimatedSprite2D.play("attack")
		isAttacking = true
		enemy_colided_player.emit()
	
func _on_animated_sprite_2d_animation_finished() -> void:
	isAttacking = false
