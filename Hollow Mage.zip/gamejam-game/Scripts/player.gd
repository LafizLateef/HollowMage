extends CharacterBody2D

@export var SPEED = 15000
@export var JUMP_THRESHOLD = 0
@export var canShoot = true
signal despawnSpawn
var canPlayAnimations = true
var JUMP_VELOCITY = 0
const MAX_THRESHOLD = 80
var CHARGE_THRESHOLD := 0
var knockback = false
var fireballScene := load("res://Scenes/fireball.tscn")
var deadScene := load("res://Scenes/Death Screen.tscn")
signal resetLava

# Called when the node enters the scene tree for the first time.
func updateMarkerPosition():
	#if $PlayerSprite.flip_h:
		#$Marker2D.position.x = -abs(marker.position.x)
	#else:
		#$Marker2D.position.x = abs(marker.position.x)
	if $PlayerSprite.flip_h:
		$Marker2D.position.x = -abs($Marker2D.position.x)
	else:
		$Marker2D.position.x = abs($Marker2D.position.x)

func spawn_fireball():
	var fireball = fireballScene.instantiate()
	$"../FireBalls".add_child(fireball)

func _attack_animation_over():
	spawn_fireball()
	canPlayAnimations = true
	$"../FIreballTimer".start()

func _falling_finished():
	canPlayAnimations = true

func reset():
	resetLava.emit()
	
func _physics_process(delta: float) -> void:
	if Global.playerDead:
		reset()
		get_tree().change_scene_to_file("res://Scenes/menu.tscn")
		#var label = deadScene.instantiate()
		#$"../Labels".add_child(label)
		return
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	else:
		knockback = false
	# Handle jump.
	#if Input.is_action_just_released("jump"):
		#canPlayAnimations = false
		#$PlayerSprite.play("jump")

	if Input.is_action_pressed("jump") and is_on_floor() and Global.JUMPS > 0:
		if JUMP_THRESHOLD < MAX_THRESHOLD:
			JUMP_THRESHOLD += 14

	else:
		velocity.y -= JUMP_THRESHOLD
		if velocity.y > 0 and not is_on_floor():
			JUMP_THRESHOLD -= 5
		if JUMP_THRESHOLD > 0:
			despawnSpawn.emit()
			JUMP_THRESHOLD -= 4
		#if JUMP_THRESHOLD <= 0 and is_on_floor():
			#canPlayAnimations = true

	# Left Right Movement
	var direction := Input.get_axis("left", "right")
	if direction < 0:
		$PlayerSprite.flip_h = true
	if direction > 0:
		$PlayerSprite.flip_h = false
	if direction == 0 and canPlayAnimations:
		$PlayerSprite.play("idle")
	elif canPlayAnimations:
		$PlayerSprite.play("walk")
	if not knockback:
		if direction:
			velocity.x = direction * SPEED * delta
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)

	# Spawning Fireballs
	updateMarkerPosition()
	if Input.is_action_just_pressed("attack") and canShoot:
		canShoot = true
		canPlayAnimations = false
		$PlayerSprite.play("attack")
		$PlayerSprite.connect("animation_finished", Callable(self, "_attack_animation_over"))
	move_and_slide()

func _on_f_ireball_timer_timeout() -> void:
	canShoot = true

func _on_enemy_1_enemy_colided_player() -> void:  # knock player
	knockback = true
	velocity.x = -700
	JUMP_THRESHOLD = 0
